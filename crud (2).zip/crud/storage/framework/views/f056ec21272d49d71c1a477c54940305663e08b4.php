<link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
<title>Crud Laravel</title>
<h1 align="center">CRUD Laravel</h1>
<br>
<div class="kotak">
<?php if( Session::get('masuk') !=""): ?>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong><?php echo e(Session::get('masuk')); ?></strong>
</div>
<?php endif; ?>

<?php if( Session::get('update') !=""): ?>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong><?php echo e(Session::get('update')); ?></strong>
</div>
<?php endif; ?>
<br>
<br>
<a href="/crud/tambah">Tambah Data</a>
<br>
<br>
    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jk</th>
            <th>No Hp</th>
            <th>Alamat</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $crud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($c->nama); ?></td>
            <?php if($c->jk == 'L'): ?>
            <td>Laki - laki</td>
            <?php else: ?>
            <td>Perempuan</td>
            <?php endif; ?>
            <td><?php echo e($c->no_hp); ?></td>
            <td><?php echo e($c->alamat); ?></td>
            <td><a href="/crud/edit/<?php echo e($c->id); ?>">Edit</a> | <a href="/crud/hapus/<?php echo e($c->id); ?>" onclick="return confirm('Apakah anda yakin?')">Hapus</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH D:\xampp\htdocs\crud\resources\views/crud/index.blade.php ENDPATH**/ ?>