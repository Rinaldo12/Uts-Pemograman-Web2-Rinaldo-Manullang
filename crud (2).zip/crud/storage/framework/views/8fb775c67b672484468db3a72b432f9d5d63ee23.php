<link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
<title>Crud Laravel</title>
<br>
<div class="kotak">
<div class="kotak2">
<h1 align="center">Edit Data</h1>
    <form action="/crud/update" method="post">
    <?php echo csrf_field(); ?>
    <label for="">Nama</label>
    <input type="hidden" value="<?php echo e($crud->id); ?>" name="id">
    <input type="text" name="nama" value="<?php echo e($crud->nama); ?>" required>

    <label for="jk">Jenis Kelamin</label>
    <select name="jk" required>
    <?php if($crud->jk == 'L'): ?>
      <option value="L" selected>Laki - laki</option>
      <option value="P">Perempuan</option>
    <?php else: ?>
        <option value="L">Laki - laki</option>
        <option value="P" selected>Perempuan</option>
    <?php endif; ?>
    </select>

    <label for="">No Hp</label>
    <input type="text" name="no_hp" value="<?php echo e($crud->no_hp); ?>" required>

    <label for="">Alamat</label>
    <input type="text" name="alamat" value="<?php echo e($crud->alamat); ?>" required>

    <br>
    <br>

    <input type="submit" value="Submit">
    </form>
</div>
</div><?php /**PATH D:\xampp\htdocs\crud\resources\views/crud/edit.blade.php ENDPATH**/ ?>