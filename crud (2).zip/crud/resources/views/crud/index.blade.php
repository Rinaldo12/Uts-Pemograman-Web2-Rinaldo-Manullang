<link rel="stylesheet" href="{{url('style.css')}}">
<title>Crud Laravel</title>
<h1 align="center">CRUD Laravel</h1>
<br>
<div class="kotak">
@if( Session::get('masuk') !="")
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>{{Session::get('masuk')}}</strong>
</div>
@endif

@if( Session::get('update') !="")
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>{{Session::get('update')}}</strong>
</div>
@endif
<br>
<br>
<a href="/crud/tambah">Tambah Data</a>
<br>
<br>
    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jk</th>
            <th>No Hp</th>
            <th>Alamat</th>
            <th>Aksi</th>
        </tr>
        @foreach($crud as $i => $c)
        <tr>
            <td>{{++$i}}</td>
            <td>{{$c->nama}}</td>
            @if($c->jk == 'L')
            <td>Laki - laki</td>
            @else
            <td>Perempuan</td>
            @endif
            <td>{{$c->no_hp}}</td>
            <td>{{$c->alamat}}</td>
            <td><a href="/crud/edit/{{$c->id}}">Edit</a> | <a href="/crud/hapus/{{$c->id}}" onclick="return confirm('Apakah anda yakin?')">Hapus</a></td>
        </tr>
        @endforeach
    </table>
</div>