<link rel="stylesheet" href="{{url('style.css')}}">
<title>Crud Laravel</title>
<br>
<div class="kotak">
<div class="kotak2">
<h1 align="center">Input Data</h1>
    <form action="/crud/store" method="post">
    @csrf
    <label for="">Nama</label>
    <input type="text" name="nama" required>

    <label for="jk">Jenis Kelamin</label>
    <select name="jk" required>
    <option value="" disabled selected>Pilih Jenis Kelamin</option>
      <option value="L">Laki - laki</option>
      <option value="P">Perempuan</option>
    </select>

    <label for="">No Hp</label>
    <input type="text" name="no_hp" required>

    <label for="">Alamat</label>
    <input type="text" name="alamat" required>

    <br>
    <br>

    <input type="submit" value="Submit">
    </form>
</div>
</div>