<link rel="stylesheet" href="{{url('style.css')}}">
<title>Crud Laravel</title>
<br>
<div class="kotak">
<div class="kotak2">
<h1 align="center">Edit Data</h1>
    <form action="/crud/update" method="post">
    @csrf
    <label for="">Nama</label>
    <input type="hidden" value="{{$crud->id}}" name="id">
    <input type="text" name="nama" value="{{$crud->nama}}" required>

    <label for="jk">Jenis Kelamin</label>
    <select name="jk" required>
    @if($crud->jk == 'L')
      <option value="L" selected>Laki - laki</option>
      <option value="P">Perempuan</option>
    @else
        <option value="L">Laki - laki</option>
        <option value="P" selected>Perempuan</option>
    @endif
    </select>

    <label for="">No Hp</label>
    <input type="text" name="no_hp" value="{{$crud->no_hp}}" required>

    <label for="">Alamat</label>
    <input type="text" name="alamat" value="{{$crud->alamat}}" required>

    <br>
    <br>

    <input type="submit" value="Submit">
    </form>
</div>
</div>