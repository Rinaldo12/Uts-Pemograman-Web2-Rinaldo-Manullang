<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class CrudController extends Controller
{
  
    public function index()
    {
        $crud = DB::table('tb_crud')->get();

        return view('crud/index',compact('crud'));
    }

    public function tambah()
    {
        return view('crud/tambah');
    }

    public function store(Request $request)
    {
            DB::table('tb_crud')->insert([
                'nama' => $request->nama,
                'jk' => $request->jk,
                'no_hp' => $request->no_hp,
                'alamat' => $request->alamat,
                'alamat' => $request->alamat,
        ]);

        return redirect('crud')->with('masuk','Data Berhasil Di Input');
        
    }

    public function edit($id)
    {
        $crud = DB::table('tb_crud')->where('id',$id)->first();
       
        return view('crud/edit',compact('crud'));
    }

    public function update(Request $request)
    {
        
        DB::table('tb_crud')->where('id',$request->id)->update([
            'nama' => $request->nama,
            'jk' => $request->jk,
            'no_hp' => $request->no_hp,
            'alamat' => $request->alamat,
            'alamat' => $request->alamat,
        ]);

        return redirect('crud')->with('update','Data Berhasil Di Update');
        
    }

    public function hapus($id)
    {
        DB::table('tb_crud')->where('id',$id)->delete();

        return redirect('crud')->with('update','Data Berhasil Di Hapus');
    }
}
